// Function to toggle dropdown visibility
function toggleDropdown(dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    if (dropdown.style.display === 'block') {
      dropdown.style.display = 'none';
    } else {
      dropdown.style.display = 'block';
    }
  }
  
// Function to toggle dropdown visibility
function toggleDropdown(subdropdownId) {
    const subdropdown = document.getElementById(subdropdownId);
    if (subdropdown.style.display === 'block') {
      subdropdown.style.display = 'none';
    } else {
      subdropdown.style.display = 'block';
    }
  }
  
  // <img
  //         class="w-full bg-center bg-cover"
  //         src="https://static1.simpleflyingimages.com/wordpress/wp-content/uploads/2021/10/acft-a350-4.jpg"
  //         alt=""

  